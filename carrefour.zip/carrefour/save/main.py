from kafka import KafkaConsumer
import sqlite3, json

basesqlite = sqlite3.connect("/data/db")
contactdb = basesqlite.cursor()
contactdb.execute("CREATE TABLE IF NOT EXISTS t(j)")

for m in KafkaConsumer(
    "tickets",
    bootstrap_servers="kafka:9092",
    value_deserializer=lambda x: json.loads(x.decode())
):
    contactdb.execute("INSERT INTO t VALUES(?)", [json.dumps(m.value)])
    basesqlite.commit()
