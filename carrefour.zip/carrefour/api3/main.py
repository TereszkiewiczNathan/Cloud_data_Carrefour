from fastapi import FastAPI
import sqlite3, json

api3 = FastAPI()

@api3.get("/tickets")
def readticket():
    basesqlite = sqlite3.connect("/data/db")
    contactdb = basesqlite.cursor()
    lignes = contactdb.execute("SELECT j FROM t")
    return [json.loads(ligne[0]) for ligne in lignes]
