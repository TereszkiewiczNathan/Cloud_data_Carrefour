from fastapi import FastAPI, Request
from kafka import KafkaProducer
import json

api=FastAPI()
ticketsend=KafkaProducer(bootstrap_servers="kafka:9092",value_serializer=lambda v: json.dumps(v).encode())

@api.post("/ticketsend")
async def ticketsendchemin(requete: Request):
    ticketsend.send("tickets", await requete.json())
    return "c'est bon"