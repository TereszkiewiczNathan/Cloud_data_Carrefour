import streamlit as s, requests

reponse = requests.get("http://api3:8003/tickets")
s.write(reponse.json())
