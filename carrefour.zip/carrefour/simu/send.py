import requests

ticket = {
    "magasin": "Lyon",
    "produit": "pomme",
    "quantite": 3,
    "montant": 2.75
}

reponse = requests.post("http://localhost:8001/ticketsend", json=ticket)
print(reponse.status_code, reponse.text)
